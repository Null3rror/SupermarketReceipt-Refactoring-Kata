#ifndef CPP_PRODUCTUNIT_H
#define CPP_PRODUCTUNIT_H


enum class ProductUnit {
    Kilo,
    Each,
};


#endif //CPP_PRODUCTUNIT_H
