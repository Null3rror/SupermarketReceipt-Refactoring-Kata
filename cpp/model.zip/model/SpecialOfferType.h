#ifndef CPP_SPECIALOFFERTYPE_H
#define CPP_SPECIALOFFERTYPE_H


enum class SpecialOfferType {
    ThreeForTwo,
    TenPercentDiscount,
    TwoForAmount,
    FiveForAmount,
};


#endif //CPP_SPECIALOFFERTYPE_H
